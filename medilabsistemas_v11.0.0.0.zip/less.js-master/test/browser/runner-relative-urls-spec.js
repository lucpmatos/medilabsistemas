describe("less.js browser test - relative url's", function() {
    testLessEqualsInDocument();
});
