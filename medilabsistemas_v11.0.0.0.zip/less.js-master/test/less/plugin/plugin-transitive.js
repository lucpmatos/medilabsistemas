functions.addMultiple({
    "test-transitive" : function() {
        return new tree.Anonymous( "transitive" );
    }
});
